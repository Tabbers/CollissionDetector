#include "CollisionData.h"

void CollisionData::GenerateDataFormTriangle(Triangle & tri)
{
}
