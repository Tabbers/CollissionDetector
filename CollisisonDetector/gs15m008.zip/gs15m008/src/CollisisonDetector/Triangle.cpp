#include "Triangle.h"

Triangle Triangle::Generate()
{

	return Triangle();
}
