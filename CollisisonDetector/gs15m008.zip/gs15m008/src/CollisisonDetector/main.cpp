#include "core.h"

int main(int argc, char *argv[])
{
	Core core;

	core.Init();
	core.Run();

	return 0;
}